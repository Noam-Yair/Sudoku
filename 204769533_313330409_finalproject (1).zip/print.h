/*functions to print current board*/

void print();
void cell_separator();
void separator_row();


