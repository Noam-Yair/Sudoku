/*implementation of processing the user's input
calling the functions according to the input, if was entered right*/

void initial();
void exe_func(int ind,  char* arr[3], int edit_flag);

void print_MNC();
int check_parameter(char*arr[3],int ind);
int check(char*arr[3],int len);
void num_sol();
